#include "AVLTree.h"

using namespace std;

AVLTree::AVLTree()
{
   size = 0;
   height = 0;
   root = nullptr;
}

AVLTree::AVLTree(TreeNode *&root)
{
   size = 0;
   height = 0;
   this->root = root;
}
AVLTree::~AVLTree()
{
   // Use postorder here
}

bool AVLTree::insertAVL(int key, string value)
{
   TreeNode *nodeToInsert = new TreeNode(key, value);
   if (root == nullptr)
   {
      root = nodeToInsert;
      nodeToInsert->parent = nullptr;
      return true;
   }
   TreeNode *currentNode = root;
   while (currentNode)
   {
      if (nodeToInsert->key < currentNode->key)
      {
         // Go left
         if (currentNode->left == nullptr)
         {
            currentNode->left = nodeToInsert;
            nodeToInsert->parent = currentNode;
            currentNode = nullptr;
         }
         else
            currentNode = currentNode->left;
      }
      else
      {
         if (currentNode->right == nullptr)
         {
            currentNode->right = nodeToInsert;
            nodeToInsert->parent = currentNode;
            return true;
         }
         else
            currentNode = currentNode->right;
      }
   }
   // going back up
   currentNode = currentNode->parent;
   while (currentNode)
   {
      rebalance(currentNode);
      currentNode = currentNode->parent;
   }
}
bool AVLTree::insertBST(int key, string value)
{
   TreeNode *nodeToInsert = new TreeNode(key, value);
   if (root == nullptr)
      root = nodeToInsert;
   TreeNode *currentNode = root;
   // Currently this is for bst
   while (currentNode != nullptr)
   {
      if (currentNode->key <= key)
      {
         if (currentNode->right == nullptr)
         {

            currentNode->right = nodeToInsert;
            nodeToInsert->parent = currentNode;
            currentNode = nullptr;
         }
         else
            currentNode = currentNode->right;
      }
      else
      {
         if (currentNode->left == nullptr)
         {
            currentNode->left = nodeToInsert;
            nodeToInsert->parent = currentNode;
            currentNode = nullptr;
         }
         else
            currentNode = currentNode->left;
      }
   }
   size++;
}
int AVLTree::getHeight()
{
   return height;
}
int AVLTree::getSize()
{
   return size;
}
ostream &operator<<(ostream &os, const AVLTree &me)
{
}
AVLTree &AVLTree::operator=(const AVLTree &)
{
}
bool AVLTree::find(int key, string &value)
{
   TreeNode *currentNode = this->root;
   while (currentNode != nullptr)
   {
      if (currentNode->key == key)
      {
         value = currentNode->value;
         return true;
      }
      if (currentNode->key < key)
      {
         currentNode = currentNode->left;
      }
      if (currentNode->key >= key)
      {
         currentNode = currentNode->right;
      }
   }
   value = key + " not found";
   return false;
}

AVLTree::TreeNode *AVLTree::search(int key)
{

   return nullptr;
}
vector<string> AVLTree::findRange(int lowkey, int highkey)
{
}

AVLTree::TreeNode *AVLTree::SingleRightRotation(TreeNode *problemNode)
{
}
AVLTree::TreeNode *AVLTree::SingleLeftRotation(TreeNode *problemNode)
{
}
AVLTree::TreeNode *AVLTree::DoubleRightRotation(TreeNode *problemNode)
{
}
AVLTree::TreeNode *AVLTree::DoubleLeftRotation(TreeNode *problemNode)
{
}